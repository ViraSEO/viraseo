document.getElementById("openDashboard").addEventListener("click", () => {
  chrome.tabs.create({
    url: "https://viraseo.vercel.app"
  });
});