(function () {
  if (document.getElementById("viraseo-panel")) return;

  const viralWords = [
    "secret", "best", "top", "viral", "hidden", "truth", "warning",
    "shocking", "crazy", "powerful", "mistake", "ultimate", "new"
  ];

  const panel = document.createElement("div");
  panel.id = "viraseo-panel";

  panel.innerHTML = `
  <div class="viraseo-header" id="viraseo-drag">
    <span>🚀 ViraSEO Assistant</span>
    <div>
      <button id="viraseo-settings">⚙️</button>
<button id="viraseo-minimize">−</button>
<button id="viraseo-close">✕</button>
    </div>
  </div>

  <div class="viraseo-body">

  <div id="viraseo-settings-panel" class="viraseo-card" style="display:none;">
  <div class="viraseo-label">Settings</div>

  <button id="viraseo-reset-position" class="viraseo-small-btn">
    Reset Panel Position
  </button>

  <button id="viraseo-clear-history" class="viraseo-small-btn">
    Clear Title History
  </button>

  <button id="viraseo-wider-panel" class="viraseo-small-btn">
    Toggle Wide Panel
  </button>
</div>
<div class="viraseo-card viraseo-health-card">

  <div class="viraseo-label">
    ViraSEO Quick Score
  </div>

  <div style="
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:10px;
    text-align:center;
    margin-top:10px;
  ">

    <div>
      <div style="font-size:11px;color:#94a3b8;">SEO</div>
      <div id="viraseo-score" class="viraseo-score">0/100</div>
    </div>

    <div>
      <div style="font-size:11px;color:#94a3b8;">CTR</div>
      <div id="viraseo-ctr" class="viraseo-score">0%</div>
    </div>

    <div>
      <div style="font-size:11px;color:#94a3b8;">VIRAL</div>
      <div id="viraseo-viral-score" class="viraseo-score">0%</div>
    </div>

  </div>


    
          
    <div class="viraseo-card">
      <div class="viraseo-label">AI Title Generator</div>
      <button id="viraseo-generate-title" class="viraseo-small-btn">Generate Titles</button>
      <div id="viraseo-ai-titles" class="viraseo-ai-box">Open a video edit page first.</div>
    </div>

    <div class="viraseo-card">
      <div class="viraseo-label">A/B Testing Lab</div>
      <button id="viraseo-abtest-btn" class="viraseo-small-btn">Compare Titles</button>
      <div id="viraseo-abtest-results" class="viraseo-ai-box">Generate titles first.</div>
    </div>

    <div class="viraseo-card">
      <div class="viraseo-label">Title Rewriter</div>
      <button id="viraseo-rewrite-title" class="viraseo-small-btn">Rewrite Title</button>
      <div id="viraseo-rewrite-results" class="viraseo-ai-box">Waiting for video title</div>
    </div>

<div class="viraseo-card">
  <div class="viraseo-label" id="viraseo-history-toggle" style="cursor:pointer;">
    Title History ▼
  </div>

  <div id="viraseo-history" class="viraseo-ai-box" style="display:none;">
    No saved titles yet.
  </div>
</div>

    <div class="viraseo-card">
      <div class="viraseo-label">AI Tag Generator</div>
      <button id="viraseo-generate-tags" class="viraseo-small-btn">Generate Tags</button>
      <div id="viraseo-ai-tags" class="viraseo-tags"><span>Waiting...</span></div>
    </div>

    

    <div class="viraseo-card">
  <div class="viraseo-label">AI Description Generator</div>
  <button id="viraseo-generate-description" class="viraseo-small-btn">
    Generate Description
  </button>
  <div id="viraseo-description-box" class="viraseo-ai-box">
    Waiting for video title
  </div>
</div>

    <div class="viraseo-card">
  <div class="viraseo-label">Tag Quality Analyzer</div>
<button id="viraseo-keyword-btn" class="viraseo-small-btn">Analyze YouTube Tags</button>
<div id="viraseo-keyword-box" class="viraseo-ai-box">
  Add tags in YouTube Studio, then analyze.
</div>
 
</div>
</div>

    <div class="viraseo-card">
      <div class="viraseo-label">Competitor Snapshot</div>
      <button id="viraseo-competitor-btn" class="viraseo-small-btn">Analyze Copied URL</button>
      <div id="viraseo-competitor-box" class="viraseo-ai-box">Copy a YouTube video URL first.</div>
    </div>

    <div class="viraseo-card">
      <div class="viraseo-label">Thumbnail Analyzer</div>
      <button id="viraseo-analyze-thumbnail" class="viraseo-small-btn">Analyze Thumbnail</button>
      <div id="viraseo-thumbnail-result" class="viraseo-ai-box">
        Open a video edit page and choose a thumbnail.
      </div>
    </div>

    <div class="viraseo-card">
      <div class="viraseo-label">Title Hook Analyzer</div>
      <div id="viraseo-viral" class="viraseo-tags">
<span>No viral keywords detected</span>
</div>
    </div>

    <button id="viraseo-btn">Open ViraSEO Dashboard</button>
  </div>
`;

  document.body.appendChild(panel);
  setTimeout(renderTitleHistory, 300);
    protectViraSEOInputs();
  setTimeout(() => {
  const historyToggle = document.getElementById("viraseo-history-toggle");
  const historyBox = document.getElementById("viraseo-history");

  if (historyToggle && historyBox) {
    historyToggle.addEventListener("click", () => {
      const isOpen = historyBox.style.display === "block";
      historyBox.style.display = isOpen ? "none" : "block";
      historyToggle.textContent = isOpen ? "Title History ▼" : "Title History ▲";
    });
  }
}, 400);
  
    function protectViraSEOInputs() {
  const fields = panel.querySelectorAll("input, textarea");

  fields.forEach((field) => {
    ["mousedown", "mouseup", "click", "dblclick", "keydown", "keyup", "keypress", "input", "paste"].forEach((eventName) => {
      field.addEventListener(eventName, (e) => {
        e.stopPropagation();
      }, true);
    });
  });
}

  const savedX = localStorage.getItem("viraseo-panel-left");
  const savedY = localStorage.getItem("viraseo-panel-top");

  if (savedX && savedY) {
    panel.style.left = savedX;
    panel.style.top = savedY;
    panel.style.right = "auto";
    panel.style.bottom = "auto";
  }

  document.getElementById("viraseo-btn").addEventListener("click", () => {
    window.open("https://viraseo.vercel.app", "_blank");
  });

  document.getElementById("viraseo-close").addEventListener("click", () => panel.remove());

  document.getElementById("viraseo-settings").addEventListener("click", () => {
  const settings = document.getElementById("viraseo-settings-panel");
  settings.style.display = settings.style.display === "none" ? "block" : "none";
});

document.getElementById("viraseo-minimize").addEventListener("click", () => {
  const body = panel.querySelector(".viraseo-body");
  body.style.display = body.style.display === "none" ? "block" : "none";
});

document.getElementById("viraseo-reset-position").addEventListener("click", () => {
  localStorage.removeItem("viraseo-panel-left");
  localStorage.removeItem("viraseo-panel-top");

  panel.style.left = "auto";
  panel.style.top = "auto";
  panel.style.right = "20px";
  panel.style.bottom = "20px";
});

document.getElementById("viraseo-clear-history").addEventListener("click", () => {
  localStorage.removeItem("viraseo-title-history");
  renderTitleHistory();
});

document.getElementById("viraseo-wider-panel").addEventListener("click", () => {
  panel.classList.toggle("viraseo-wide");

  localStorage.setItem(
    "viraseo-wide",
    panel.classList.contains("viraseo-wide") ? "1" : "0"
  );
});

if (localStorage.getItem("viraseo-wide") === "1") {
  panel.classList.add("viraseo-wide");
}

   

  let isDragging = false;
  let offsetX = 0;
  let offsetY = 0;

  const dragHandle = document.getElementById("viraseo-drag");

  dragHandle.addEventListener("mousedown", (e) => {
  if (e.target.tagName === "BUTTON" || e.target.tagName === "INPUT") return;

  isDragging = true;
  offsetX = e.clientX - panel.offsetLeft;
  offsetY = e.clientY - panel.offsetTop;
  panel.style.right = "auto";
  panel.style.bottom = "auto";
});

  document.addEventListener("mousemove", (e) => {
    if (!isDragging) return;

    let left = e.clientX - offsetX;
    let top = e.clientY - offsetY;

    left = Math.max(5, Math.min(left, window.innerWidth - panel.offsetWidth - 5));
    top = Math.max(5, Math.min(top, window.innerHeight - 80));

    panel.style.left = `${left}px`;
    panel.style.top = `${top}px`;
  });

  document.addEventListener("mouseup", () => {
    if (!isDragging) return;
    isDragging = false;
    localStorage.setItem("viraseo-panel-left", panel.style.left);
    localStorage.setItem("viraseo-panel-top", panel.style.top);
  });

  function findTitleInput() {
    const inputs = Array.from(document.querySelectorAll('input, textarea, [contenteditable="true"]'));

    return inputs.find((el) => {
      const aria = (el.getAttribute("aria-label") || "").toLowerCase();
      const placeholder = (el.getAttribute("placeholder") || "").toLowerCase();

      return (
        aria.includes("title") ||
        aria.includes("başlık") ||
        placeholder.includes("title") ||
        placeholder.includes("başlık")
      );
    });
  }

  function getTitleValue(input) {
    if (!input) return "";
    if (input.value) return input.value.trim();
    return (input.innerText || "").trim();
  }

function calculatePowerMeters(title, score) {
  if (!title) {
    return {
      seo: 0,
      curiosity: 0,
      emotion: 0,
      clickability: 0
    };
  }

  const lower = title.toLowerCase();

  const curiosityWords = [
    "secret", "hidden", "truth", "why", "what", "how",
    "nobody", "revealed", "unexpected", "shocking"
  ];

  const emotionWords = [
    "shocking", "crazy", "powerful", "amazing", "sad",
    "angry", "emotional", "scary", "heartbreaking", "unbelievable"
  ];

  let curiosity = 20;
  let emotion = 20;
  let clickability = 20;

  if (curiosityWords.some((w) => lower.includes(w))) curiosity += 45;
  if (title.includes("?")) curiosity += 20;
  if (title.includes("!")) curiosity += 10;

  if (emotionWords.some((w) => lower.includes(w))) emotion += 45;
  if (title.includes("!")) emotion += 20;
  if (/\d/.test(title)) emotion += 10;

  if (title.length >= 35 && title.length <= 70) clickability += 35;
  if (/\d/.test(title)) clickability += 20;
  if (title.includes("?") || title.includes("!")) clickability += 15;
  if (viralWords.some((word) => lower.includes(word))) clickability += 20;

  return {
    seo: Math.min(100, score),
    curiosity: Math.min(100, curiosity),
    emotion: Math.min(100, emotion),
    clickability: Math.min(100, clickability)
  };
}

  function calculateScore(title) {
    let score = 20;
    const suggestions = [];

    if (!title) {
      return {
        score: 0,
        lengthStatus: "No Title",
        suggestions: ["Open a video edit page first."]
      };
    }

    if (title.length >= 35 && title.length <= 70) score += 30;
    else suggestions.push("Title should be between 35 and 70 characters.");

    if (/\d/.test(title)) score += 15;
    else suggestions.push("Add a number to improve click-through rate.");

    if (viralWords.some((word) => title.toLowerCase().includes(word))) score += 20;
    else suggestions.push("Add curiosity words like secret, truth, hidden or shocking.");

    if (title.includes("?") || title.includes("!")) score += 15;
    else suggestions.push("Use ? or ! to create curiosity.");

    if (score > 100) score = 100;

    let lengthStatus = "Too Short";
    if (title.length >= 35 && title.length <= 70) lengthStatus = "Good";
    if (title.length > 70) lengthStatus = "Too Long";

    if (suggestions.length === 0) suggestions.push("Title looks strong.");

    return { score, lengthStatus, suggestions };
  }

  function extractKeywords(title) {
    if (!title) return [];

    const banned = [
      "the", "and", "for", "with", "from", "this", "that",
      "video", "videos", "short", "shorts", "youtube", "your",
      "how", "why", "what", "when", "where", "about"
    ];

    return title
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, "")
      .split(" ")
      .filter((word) => word.length > 2 && !banned.includes(word))
      .slice(0, 10);
  }

  function extractCompetitorKeywords(title, description = "") {
  const text = `${title} ${description}`.toLowerCase();

  const banned = [
    "the", "and", "for", "with", "from", "this", "that", "you", "your",
    "video", "videos", "short", "shorts", "youtube", "http", "https",
    "www", "com", "watch", "subscribe", "channel", "official"
  ];

  const words = text
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((w) => w.length > 3 && !banned.includes(w));

  const counts = {};

  words.forEach((word) => {
    counts[word] = (counts[word] || 0) + 1;
  });

  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .map(([word]) => word)
    .slice(0, 12);
}

  async function generateTemplateTitles(title) {
  if (!title) return [];

  const keyword = title.replace(/[!?]/g, "").trim();

  const starters = [
    "The Hidden Truth About",
    "Nobody Talks About",
    "Why",
    "The Secret Behind",
    "What Really Happens With",
    "The Shocking Reality Of",
    "The Untold Story Of",
    "Experts Warn About",
    "The Biggest Mistake In",
    "Everything You Know About",
    "The Dark Side Of",
    "The Surprising Truth About",
    "What Nobody Tells You About",
    "The Future Of",
    "The Real Reason Behind",
    "How",
    "Top 10 Facts About",
    "Top 5 Secrets Of",
    "The Most Common Problem With",
    "The Ultimate Guide To"
  ];

  const middles = [
    "Most People Ignore",
    "That Changed Everything",
    "That Experts Don't Explain",
    "Nobody Expected",
    "That Went Viral",
    "That Could Save You Money",
    "That Could Change Your Life",
    "That Actually Works",
    "That Is Growing Fast",
    "That Everyone Should Know",
    "That Became A Huge Trend",
    "That Shocked The Internet",
    "That Nobody Believed",
    "That Is Taking Over",
    "That People Keep Missing"
  ];

  const endings = [
    "In 2026",
    "Right Now",
    "And The Results Are Crazy",
    "Before It's Too Late",
    "You Need To See This",
    "That Nobody Expected",
    "And Nobody Saw It Coming",
    "The Answer May Surprise You",
    "Explained In Minutes",
    "What Happens Next Is Incredible"
  ];

  const results = [];

  for (let i = 0; i < 5; i++) {
    const s = starters[Math.floor(Math.random() * starters.length)];
    const m = middles[Math.floor(Math.random() * middles.length)];
    const e = endings[Math.floor(Math.random() * endings.length)];

    let generated = `${s} ${keyword} ${m} ${e}`;

if (generated.length > 95) {
  generated = `${s} ${keyword}`;
}

results.push(generated);
  }

  return [...new Set(results)];
}

async function generateSmartTitles(title) {
  try {
    const res = await fetch("https://viraseo.vercel.app/api/extension/titles", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ title })
    });

    const data = await res.json();

    if (data.titles && Array.isArray(data.titles) && data.titles.length) {
      return data.titles;
    }

    return await generateTemplateTitles(title);
  } catch (e) {
  return await generateTemplateTitles(title);
}
}

  function generateTemplateTags(title) {
    if (!title) return [];

    const base = extractKeywords(title);

    return [
      ...base,
      "shorts",
      "youtube shorts",
      "viral shorts",
      "viral video",
      "content creator",
      "youtube growth",
      "youtube seo",
      "trending video"
    ].slice(0, 14);
  }
async function generateSmartTags(title) {
  try {
    const res = await fetch("https://viraseo.vercel.app/api/extension/tags", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ title })
    });

    const data = await res.json();

    if (data.tags && Array.isArray(data.tags) && data.tags.length) {
      return data.tags;
    }

    return generateTemplateTags(title);
  } catch (e) {
    return generateTemplateTags(title);
  }
}

function generateTemplateDescription(title) {
  const cleanTitle = title || "this video";

  return `Bu videoda "${cleanTitle}" konusunu sade ve anlaşılır şekilde ele alıyoruz.

Videoyu beğenmeyi, yorum yapmayı ve kanala abone olmayı unutmayın.

#youtube #shorts #viral #keşfet #video`;
}

async function generateSmartDescription(title) {
  const cacheKey = "viraseo-description-" + title.toLowerCase().trim();
  const cached = localStorage.getItem(cacheKey);

  if (cached) {
    return cached;
  }

  try {
    const res = await fetch("https://viraseo.vercel.app/api/extension/description", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ title })
    });

    const data = await res.json();

    if (data.description) {
      localStorage.setItem(cacheKey, data.description);
      return data.description;
    }

    const fallback = generateTemplateDescription(title);
    localStorage.setItem(cacheKey, fallback);
    return fallback;
  } catch (e) {
    const fallback = generateTemplateDescription(title);
    localStorage.setItem(cacheKey, fallback);
    return fallback;
  }
}

function getBestUploadTime(title) {
  if (!title) {
    return {
      day: "Waiting...",
      hours: "Open a video edit page first.",
      score: 0
    };
  }

  const lower = title.toLowerCase();

  let day = "Friday";
  let hours = "18:00 - 22:00";
  let score = 78;

  if (
    lower.includes("shorts") ||
    lower.includes("viral") ||
    lower.includes("funny") ||
    lower.includes("trend")
  ) {
    day = "Saturday";
    hours = "12:00 - 16:00";
    score = 88;
  }

  if (
    lower.includes("education") ||
    lower.includes("tutorial") ||
    lower.includes("how")
  ) {
    day = "Tuesday";
    hours = "17:00 - 20:00";
    score = 82;
  }

  if (
    lower.includes("story") ||
    lower.includes("movie") ||
    lower.includes("series") ||
    lower.includes("episode")
  ) {
    day = "Sunday";
    hours = "19:00 - 23:00";
    score = 86;
  }

  if (
    lower.includes("news") ||
    lower.includes("breaking") ||
    lower.includes("update")
  ) {
    day = "Monday";
    hours = "09:00 - 12:00";
    score = 80;
  }

  return { day, hours, score };
}
  function analyzeKeywordDifficulty(keyword) {
  if (!keyword) return null;

  const clean = keyword.trim();
  const lower = clean.toLowerCase();
  const wordCount = clean.split(/\s+/).filter(Boolean).length;

  let score = 50;
  const notes = [];

  if (wordCount === 1) {
    score -= 15;
    notes.push("Too broad");
  }

  if (wordCount >= 2 && wordCount <= 4) {
    score += 20;
    notes.push("Good tag length");
  }

  if (clean.length < 4) {
    score -= 20;
    notes.push("Too short");
  }

  if (clean.length >= 10 && clean.length <= 35) {
    score += 15;
    notes.push("Specific");
  }

  const tooGeneric = ["youtube", "shorts", "video", "viral", "trend", "funny"];
  if (tooGeneric.includes(lower)) {
    score -= 25;
    notes.push("Very generic");
  }

  if (lower.includes("how to") || lower.includes("tutorial") || lower.includes("guide")) {
    score += 10;
    notes.push("Search intent");
  }

  score = Math.max(5, Math.min(100, score));

  let quality = "Weak";
  if (score >= 75) quality = "Strong";
  else if (score >= 50) quality = "Good";

  return {
    keyword: clean,
    difficulty: score,
    competition: quality,
    opportunity: notes.slice(0, 2).join(", ") || "Basic tag"
  };
}

  function copyText(text, btn) {
    navigator.clipboard.writeText(text).then(() => {
      const old = btn.textContent;
      btn.textContent = "✅";
      setTimeout(() => {
        btn.textContent = old;
      }, 1000);
    });
  }

  function saveTitleHistory(title) {
  if (!title) return;

  let history =
    JSON.parse(localStorage.getItem("viraseo-title-history") || "[]");

  history.unshift(title);

  history = [...new Set(history)];

  history = history.slice(0, 20);

  localStorage.setItem(
    "viraseo-title-history",
    JSON.stringify(history)
  );

  renderTitleHistory();
}

function renderTitleHistory() {
  const box = document.getElementById("viraseo-history");

  if (!box) return;

  const history =
    JSON.parse(localStorage.getItem("viraseo-title-history") || "[]");

  if (!history.length) {
    box.innerHTML = "No saved titles yet.";
    return;
  }

  box.innerHTML = history
    .map(
      (title) => `
        <div class="viraseo-history-row">
          <span>${title}</span>

          <button
            class="viraseo-copy-btn"
            data-copy="${title.replace(/"/g, "&quot;")}"
          >
            📋
          </button>
        </div>
      `
    )
    .join("");

  box.querySelectorAll(".viraseo-copy-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      copyText(btn.dataset.copy, btn);
    });
  });
}

  function findThumbnailImage() {

    const directThumb = Array.from(
  document.querySelectorAll('img[src*="ytimg.com/vi/"], img[src*="ytimg.com/vi_webp/"]')
).find((img) => !img.closest("#viraseo-panel"));

if (directThumb) {
  return directThumb;
}

  const images = Array.from(document.querySelectorAll("img"))
  .filter((img) => !img.closest("#viraseo-panel"));

  const candidates = images
    .map((img) => {
      const src = img.src || "";
      const alt = (img.alt || "").toLowerCase();
      const aria = (img.getAttribute("aria-label") || "").toLowerCase();

      const width = img.naturalWidth || img.width || 0;
      const height = img.naturalHeight || img.height || 0;
      const rect = img.getBoundingClientRect();

      let score = 0;

      if (src.includes("i.ytimg.com")) score += 40;
      if (src.includes("ytimg.com")) score += 30;
      if (src.includes("/vi/")) score += 35;
      if (src.includes("hqdefault")) score += 35;
      if (src.includes("maxresdefault")) score += 35;
      if (src.includes("mqdefault")) score += 25;

      if (alt.includes("thumbnail")) score += 25;
      if (aria.includes("thumbnail")) score += 25;

      if (width >= 320 && height >= 180) score += 20;
      if (rect.width >= 160 && rect.height >= 90) score += 20;

      const ratio = width && height ? width / height : rect.width / rect.height;

      if (ratio > 1.5 && ratio < 1.9) score += 20;

      if (src.includes("avatar")) score -= 80;
      if (src.includes("profile")) score -= 80;
      if (src.includes("channel")) score -= 60;
      if (src.includes("s88")) score -= 70;
      if (src.includes("s176")) score -= 70;

      return {
        img,
        score,
        src
      };
    })
    .filter((item) => item.score > 30)
    .sort((a, b) => b.score - a.score);

  return candidates.length ? candidates[0].img : null;
}

  async function analyzeThumbnail() {
  const resultBox = document.getElementById("viraseo-thumbnail-result");
  const img = findThumbnailImage();

  if (!img) {
    resultBox.innerHTML = `
      <div class="viraseo-warning">⚠️ No thumbnail found.</div>
      <div>Open a video edit page and upload/select a thumbnail.</div>
    `;
    return;
  }

  const width = img.naturalWidth || img.width || 0;
  const height = img.naturalHeight || img.height || 0;
  const ratio = width && height ? width / height : 0;
  const src = img.src || "";

  resultBox.innerHTML = "Analyzing thumbnail with AI...";

  try {
    const res = await fetch("https://viraseo.vercel.app/api/extension/thumbnail", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        imageUrl: src,
        width,
        height,
        ratio
      })
    });

    const data = await res.json();

    if (!res.ok) {
      resultBox.innerHTML = `
        <div class="viraseo-warning">⚠️ ${data.error || "Thumbnail analysis failed."}</div>
      `;
      return;
    }

    resultBox.innerHTML = `
      <div class="viraseo-thumbnail-score">Thumbnail Score: ${data.score}/100</div>

      <div class="viraseo-thumb-preview">
        <img src="${src}" />
      </div>

      <div class="viraseo-keyword-line">
        <span>CTR Potential</span>
        <b>${data.ctrPotential}</b>
      </div>

      <div class="viraseo-keyword-line">
        <span>Resolution</span>
        <b>${width}x${height}</b>
      </div>

      <div class="viraseo-keyword-line">
        <span>Ratio</span>
        <b>${ratio ? ratio.toFixed(2) : "Unknown"}</b>
      </div>

      <div class="viraseo-label" style="margin-top:10px;">AI Checks</div>
      ${(data.checks || []).map((c) => `<div class="viraseo-check">${c}</div>`).join("")}

      <div class="viraseo-label" style="margin-top:10px;">Recommendations</div>
      ${(data.recommendations || []).map((r) => `<div class="viraseo-note">• ${r}</div>`).join("")}
    `;
  } catch (error) {
    resultBox.innerHTML = `
      <div class="viraseo-warning">⚠️ Could not analyze thumbnail.</div>
      <div class="viraseo-note">Check API deployment and try again.</div>
    `;
  }
}

document.getElementById("viraseo-generate-title").addEventListener("click", async () => {
  const titleInput = findTitleInput();
  const title = getTitleValue(titleInput);
  const box = document.getElementById("viraseo-ai-titles");

  if (!title) {
    box.innerHTML = `<div class="viraseo-warning">⚠️ Enter a video title first.</div>`;
    return;
  }

  box.innerHTML = "Generating AI titles...";

  let titles = [];

  try {
    titles = await generateSmartTitles(title);
  } catch (e) {
    box.innerHTML = `<div class="viraseo-warning">⚠️ Title generation failed.</div>`;
    return;
  }

  const best = getBestTitle(titles);

  if (best) {
  saveTitleHistory(best.title);
}

  box.innerHTML = `
    ${
      best
        ? `
          <div class="viraseo-best-title">
            <div class="viraseo-best-badge">🏆 BEST TITLE</div>
            <div class="viraseo-best-text">${best.title}</div>
            <div class="viraseo-best-meta">
              SEO: ${best.score}/100 • Grade: ${best.grade}
            </div>
          </div>
        `
        : ""
    }

    ${titles.map((t, i) => {
      const length = t.length;

      return `
        <div class="viraseo-ai-title">
          <span>
            ${i + 1}. ${t}
            <small class="viraseo-title-meta">
              ${length}/100 ${length > 100 ? "⚠ TOO LONG" : ""}
            </small>
          </span>
          <button class="viraseo-copy-btn" data-copy="${t.replace(/"/g, "&quot;")}">📋</button>
        </div>
      `;
    }).join("")}
  `;

  box.querySelectorAll(".viraseo-copy-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      copyText(btn.getAttribute("data-copy"), btn);
    });
  });
});


  function getTitleGrade(score) {
  if (score >= 90) return "A+";
  if (score >= 80) return "A";
  if (score >= 70) return "B";
  if (score >= 60) return "C";
  return "D";
}

function getBestTitle(titles) {
  let best = null;

  titles.forEach((title) => {
    const result = calculateScore(title);
    
    const grade = getTitleGrade(result.score);

    const item = {
  title,
  score: result.score,
  grade
};

    if (!best || item.score > best.score) {
      best = item;
    }
  });

  return best;
}

function compareTitles(titles) {
  return titles
    .map((title) => {
      const score = calculateScore(title);

      const ctr = Math.min(
        15,
        Math.round(
          score.score / 10 +
          (title.includes("?") ? 2 : 0) +
          (title.length < 65 ? 1 : 0)
        )
      );

      const viral = Math.min(100, Math.round(score.score + ctr * 2));

      return {
        title,
        seo: score.score,
        ctr,
        viral
      };
    })
    .sort((a, b) => b.viral - a.viral);
}

function rewriteTitles(title) {
  if (!title) return [];

  const cleanTitle = title.replace(/[!?]/g, "").trim();

  return [
    `The Hidden Truth Behind ${cleanTitle}`,
    `Nobody Expected This: ${cleanTitle}`,
    `The Secret Reason ${cleanTitle} Matters`,
    `${cleanTitle} | What Most People Miss`,
    `Why ${cleanTitle} Is Getting Attention`
  ];
}

function setTitleValue(newTitle) {
  const input = findTitleInput();
  if (!input) return false;

  input.focus();

  if ("value" in input) {
    input.value = newTitle;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  input.innerText = newTitle;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

document.getElementById("viraseo-rewrite-title").addEventListener("click", () => {
  const titleInput = findTitleInput();
  const title = getTitleValue(titleInput);
  const box = document.getElementById("viraseo-rewrite-results");

  if (!title) {
    box.innerHTML = `<div class="viraseo-warning">⚠️ Enter a video title first.</div>`;
    return;
  }

  const rewrites = rewriteTitles(title);
  const best = getBestTitle(rewrites);

  if (best) {
  saveTitleHistory(best.title);
}

  box.innerHTML = `
  ${
    best
      ? `
        <div class="viraseo-best-title">
          <div class="viraseo-best-badge">🏆 Best Choice</div>
          <div class="viraseo-best-text">${best.title}</div>
          <div class="viraseo-best-meta">
            SEO: ${best.score}/100 • Grade: ${best.grade}
          </div>
        </div>
      `
      : ""
  }

  ${rewrites
    .map((t, i) => {
      const r = calculateScore(t);
      const ctr = Math.max(1, Math.round(r.score * 0.11));
      const grade = getTitleGrade(r.score);

      return `
        <div class="viraseo-ai-title">
          <span>
            ${i + 1}. ${t}
            <small class="viraseo-title-meta">
              SEO ${r.score}/100 • CTR ${ctr}% • ${grade}
            </small>
          </span>
          <button class="viraseo-use-btn" data-title="${t.replace(/"/g, "&quot;")}">Use</button>
        </div>
      `;
    })
    .join("")}
`;

  box.querySelectorAll(".viraseo-use-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const newTitle = btn.getAttribute("data-title");
      const ok = setTitleValue(newTitle);

      btn.textContent = ok ? "Used ✅" : "Failed";
      setTimeout(() => {
        btn.textContent = "Use";
      }, 1200);
    });
  });
});
  
document.getElementById("viraseo-abtest-btn").addEventListener("click", async () => {
  const titleInput = findTitleInput();
  const title = getTitleValue(titleInput);
  const box = document.getElementById("viraseo-abtest-results");

  if (!title) {
    box.innerHTML = `<div class="viraseo-warning">⚠️ Waiting for video title</div>`;
    return;
  }

  box.innerHTML = "Comparing titles...";

  let titles = [];

  try {
    titles = await generateSmartTitles(title);
  } catch (e) {
    box.innerHTML = `<div class="viraseo-warning">⚠️ Failed to generate titles.</div>`;
    return;
  }

  const results = compareTitles(titles);

  box.innerHTML = results.map((item, index) => `
    <div class="viraseo-ab-row">
      <div class="viraseo-ab-rank">
        ${index === 0 ? "🏆 WINNER" : "#" + (index + 1)}
      </div>

      <div class="viraseo-ab-title">
        ${item.title}
      </div>

      <div class="viraseo-ab-meta">
        SEO ${item.seo} • CTR ${item.ctr}% • Viral ${item.viral}
      </div>

      <button
        class="viraseo-copy-btn"
        data-copy="${item.title.replace(/"/g, "&quot;")}"
      >
        📋 Copy
      </button>
    </div>
  `).join("");

  box.querySelectorAll(".viraseo-copy-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      copyText(btn.getAttribute("data-copy"), btn);
    });
  });
});

  document.getElementById("viraseo-generate-tags").addEventListener("click", async () => {
  const titleInput = findTitleInput();
  const title = getTitleValue(titleInput);
  const box = document.getElementById("viraseo-ai-tags");

  if (!title) {
    box.innerHTML = `<span>Enter a title first</span>`;
    return;
  }

  box.innerHTML = `<span>Generating tags...</span>`;

  const tags = await generateSmartTags(title);

  box.innerHTML = `
  ${tags.map((tag) => `<span>${tag}</span>`).join("")}

  <button id="viraseo-use-tags" class="viraseo-use-btn">
    📥 Use Tags
  </button>
`;

  const useTagsBtn = document.getElementById("viraseo-use-tags");

  if (useTagsBtn) {
    useTagsBtn.addEventListener("click", async () => {
      const ok = await setTagsValue(tags);

      useTagsBtn.textContent = ok ? "Used ✅" : "Field Not Found";

      setTimeout(() => {
        useTagsBtn.textContent = "📥 Use Tags";
      }, 1500);
    });
  }
});

document.getElementById("viraseo-generate-description").addEventListener("click", async () => {
  const titleInput = findTitleInput();
  const title = getTitleValue(titleInput);
  const box = document.getElementById("viraseo-description-box");

  if (!title) {
    box.innerHTML = `<div class="viraseo-warning">⚠️ Waiting for video title</div>`;
    return;
  }

  box.innerHTML = "Generating description...";

  const description = await generateSmartDescription(title);

  box.innerHTML = `
    <div class="viraseo-description-text">${description.replace(/\n/g, "<br>")}</div>
    <button class="viraseo-copy-btn" data-copy="${description.replace(/"/g, "&quot;")}">
      📋 Copy Description
    </button>
<button class="viraseo-use-btn" id="viraseo-use-description">
  📥 Use Description
</button>

  `;

  box.querySelector(".viraseo-copy-btn").addEventListener("click", (e) => {
    copyText(e.target.getAttribute("data-copy"), e.target);
  });

  const useDescBtn = document.getElementById("viraseo-use-description");

if (useDescBtn) {
  useDescBtn.addEventListener("click", () => {
    const ok = setDescriptionValue(description);
    useDescBtn.textContent = ok ? "Used ✅" : "Field Not Found";
    setTimeout(() => {
      useDescBtn.textContent = "📥 Use Description";
    }, 1200);
  });
}

});



  document.getElementById("viraseo-analyze-thumbnail").addEventListener("click", analyzeThumbnail);

  document.getElementById("viraseo-keyword-btn").addEventListener("click", () => {
  const box = document.getElementById("viraseo-keyword-box");

  const tags = getYouTubeTags();

  if (!tags.length) {
    box.innerHTML = `
      <div class="viraseo-warning">⚠️ No YouTube tags found.</div>
      <div class="viraseo-note">
        Add tags in YouTube Studio first, then click Analyze Tags.
      </div>
    `;
    return;
  }

  const results = tags
    .map((tag) => analyzeKeywordDifficulty(tag))
    .filter(Boolean);

  box.innerHTML = results
  .map((result) => {
    let badge = "⚠️";
    let label = "Average Tag";

    if (result.keyword.split(/\s+/).length === 1) {
      badge = "❌";
      label = "Too Generic";
    }

    if (result.keyword.split(/\s+/).length >= 2) {
      badge = "✅";
      label = "Good Tag";
    }

    if (result.keyword.split(/\s+/).length >= 4) {
      badge = "🏆";
      label = "Strong Long-Tail Tag";
    }

    return `
      <div class="viraseo-keyword-line">
        <span>${result.keyword}</span>
        <b>${badge} ${label}</b>
      </div>
    `;
  })
  .join("");
});
function findDescriptionInput() {
  const textareas = document.querySelectorAll("ytcp-social-suggestions-textbox");

  if (textareas.length > 1) {
    return textareas[1];
  }

  const desc = document.querySelector(
    'ytcp-social-suggestions-textbox[label*="Description"], ytcp-social-suggestions-textbox[label*="Açıklama"]'
  );

  return desc;
}

function setDescriptionValue(text) {
  const input = findDescriptionInput();

  if (!input) {
    return false;
  }

  const editable = input.querySelector("#textbox");

  if (!editable) {
    return false;
  }

  editable.focus();

  editable.innerHTML = text;

  editable.dispatchEvent(
    new InputEvent("input", {
      bubbles: true,
      inputType: "insertText",
      data: text,
    })
  );

  return true;
}

function getYouTubeTags() {
  const tags = [];

  const chips = Array.from(
    document.querySelectorAll(
      "ytcp-chip, tp-yt-paper-chip, ytcp-form-chip, .chip, [class*='chip']"
    )
  );

  chips.forEach((chip) => {
    const text = (chip.innerText || chip.textContent || "").trim();

    if (
      text &&
      text.length > 1 &&
      text.length < 80 &&
      !text.toLowerCase().includes("add tag") &&
      !text.toLowerCase().includes("etiket ekle")
    ) {
      tags.push(text);
    }
  });

  const inputs = Array.from(document.querySelectorAll("input, textarea"));

  inputs.forEach((input) => {
    const aria = (input.getAttribute("aria-label") || "").toLowerCase();
    const value = (input.value || "").trim();

    if (
      value &&
      (aria.includes("tag") || aria.includes("etiket"))
    ) {
      value.split(",").forEach((tag) => {
        const clean = tag.trim();
        if (clean) tags.push(clean);
      });
    }
  });

  return [...new Set(tags)].slice(0, 20);
}

function findTagsInput() {
  const inputs = document.querySelectorAll("input");

  for (const input of inputs) {
    const aria = (input.getAttribute("aria-label") || "").toLowerCase();

    if (
      aria.includes("tag") ||
      aria.includes("etiket")
    ) {
      return input;
    }
  }

  return null;
}

async function setTagsValue(tags) {
  const input = findTagsInput();

  if (!input) {
    return false;
  }

  input.focus();

  for (const tag of tags) {
    input.value = tag;

    input.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        data: tag,
      })
    );

    input.dispatchEvent(
      new KeyboardEvent("keydown", {
        bubbles: true,
        key: "Enter",
        code: "Enter",
      })
    );

    await new Promise((r) => setTimeout(r, 150));
  }

  return true;
}

function getYouTubeVideoId(url) {
  if (!url) return null;

  const patterns = [
    /youtube\.com\/watch\?v=([^&]+)/,
    /youtu\.be\/([^?&]+)/,
    /youtube\.com\/shorts\/([^?&]+)/
  ];

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match && match[1]) return match[1];
  }

  return null;
}

async function analyzeCompetitorVideo() {
  const box = document.getElementById("viraseo-competitor-box");

  let url = "";

  try {
    url = await navigator.clipboard.readText();
  } catch (e) {
    box.innerHTML = `<div class="viraseo-warning">⚠️ Clipboard permission failed. Copy the YouTube URL again and try.</div>`;
    return;
  }

  if (!url) {
    box.innerHTML = `<div class="viraseo-warning">⚠️ Copy a YouTube video URL first.</div>`;
    return;
  }

  const videoId = getYouTubeVideoId(url);

  if (!videoId) {
    box.innerHTML = `<div class="viraseo-warning">⚠️ Copy a valid YouTube video URL.</div>`;
    return;
  }

  box.innerHTML = `Analyzing competitor video...`;

  try {
    const res = await fetch("https://viraseo.vercel.app/api/extension/competitor", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ videoId })
    });

    const data = await res.json();

    if (!res.ok) {
      box.innerHTML = `
        <div class="viraseo-warning">⚠️ ${data.error || "Could not analyze this video."}</div>
      `;
      return;
    }

    const title = data.title || "Unknown title";
    const author = data.channelTitle || "Unknown channel";
    const thumbnail = data.thumbnail || "";

    const scoreData = calculateScore(title);
    const grade = getTitleGrade(scoreData.score);
    let clickPotential = "Average";
let clickIcon = "🟡";

if (scoreData.score >= 85) {
  clickPotential = "Strong";
  clickIcon = "🔥";
} else if (scoreData.score >= 70) {
  clickPotential = "Good";
  clickIcon = "🟢";
} else if (scoreData.score < 50) {
  clickPotential = "Weak";
  clickIcon = "🔴";
}
    
    const keywords = extractKeywords(title);
const competitorKeywords = extractCompetitorKeywords(
  title,
  data.description || ""
);
    const titleLength = title.length;

    let lengthStatus = "Good";
    if (titleLength < 35) lengthStatus = "Too Short";
    if (titleLength > 70) lengthStatus = "Too Long";

    let performanceText = "Average performing video";
    let performanceIcon = "⚠️";

    if (data.performance === "High Performing") {
      performanceText = "High performing competitor";
      performanceIcon = "🔥";
    }

    if (data.performance === "Viral Level") {
      performanceText = "Viral level competitor";
      performanceIcon = "🚀";
    }

    let advice = "Use a clearer title angle, stronger hook and more specific keyword.";

    if (data.views >= 500000) {
      advice = "This video is already performing very well. Compete with a more specific angle, stronger thumbnail and sharper title hook.";
    } else if (data.views >= 100000) {
      advice = "This is a strong competitor. Try targeting a narrower keyword or a clearer viewer benefit.";
    } else if (data.views < 10000) {
      advice = "This competitor is not very strong yet. A better title, thumbnail and tags may help you outrank it.";
    }

    box.innerHTML = `
      <div class="viraseo-competitor-thumb">
        ${thumbnail ? `<img src="${thumbnail}" />` : ""}
      </div>

      <div class="viraseo-keyword-main">${title}</div>

      <div class="viraseo-keyword-line">
        <span>Channel</span>
        <b>${author}</b>
      </div>

      <div class="viraseo-keyword-line">
        <span>Views</span>
        <b>${data.formatted.views}</b>
      </div>

      <div class="viraseo-keyword-line">
        <span>Likes</span>
        <b>${data.formatted.likes}</b>
      </div>

      <div class="viraseo-keyword-line">
        <span>Comments</span>
        <b>${data.formatted.comments}</b>
      </div>

      <div class="viraseo-keyword-line">
        <span>Views / Day</span>
        <b>${data.formatted.viewsPerDay}</b>
      </div>

      <div class="viraseo-keyword-line">
        <span>Engagement</span>
        <b>${data.engagementRate}%</b>
      </div>

      <div class="viraseo-keyword-line">
        <span>Performance</span>
        <b>${performanceIcon} ${performanceText}</b>
      </div>

      <div class="viraseo-keyword-line">
        <span>Title SEO</span>
        <b>${scoreData.score}/100 • ${grade}</b>
      </div>

      <div class="viraseo-keyword-line">
  <span>Click Potential</span>
  <b>${clickIcon} ${clickPotential}</b>
</div>

      <div class="viraseo-keyword-line">
        <span>Title Length</span>
        <b>${titleLength} chars • ${lengthStatus}</b>
      </div>

      <div class="viraseo-label" style="margin-top:10px;">Detected Keywords</div>
      <div class="viraseo-label" style="margin-top:10px;">Competitor Keywords</div>
<div class="viraseo-tags">
  ${
    competitorKeywords.length
      ? competitorKeywords.map((k) => `<span>${k}</span>`).join("")
      : `<span>No competitor keywords found</span>`
  }
</div>
      <div class="viraseo-tags">
        ${
          keywords.length
            ? keywords.map((k) => `<span>${k}</span>`).join("")
            : `<span>No keywords detected</span>`
        }
      </div>

      <div class="viraseo-card" style="margin-top:10px;">
        <div class="viraseo-label">How To Compete</div>
        <div class="viraseo-note">
          ${advice}
        </div>
      </div>
    `;
  } catch (error) {
    box.innerHTML = `
      <div class="viraseo-warning">⚠️ Could not analyze this video.</div>
      <div class="viraseo-note">Check your API deployment and try again.</div>
    `;
  }
}

document
  .getElementById("viraseo-competitor-btn")
  .addEventListener("click", analyzeCompetitorVideo);

  function updatePanel() {
  if (!document.getElementById("viraseo-score")) return;

  const titleInput = findTitleInput();
  const title = getTitleValue(titleInput);
  const result = calculateScore(title);
  const meters = calculatePowerMeters(title, result.score);
  const uploadTime = getBestUploadTime(title);

  const foundViralWords = viralWords.filter((word) =>
    title.toLowerCase().includes(word)
  );

  const ctr = title ? Math.max(1, Math.round(result.score * 0.11)) : 0;

  const healthScore = title
  ? Math.round((result.score + meters.seo + meters.curiosity + meters.emotion + meters.clickability) / 5)
  : 0;

  const trendingScore = title
  ? Math.round(
      (
        result.score +
        ctr * 5 +
        meters.curiosity +
        meters.emotion +
        meters.clickability
      ) / 5
    )
  : 0;

  const viralProbability = Math.min(
  100,
  Math.round(
    (
      trendingScore +
      result.score +
      ctr * 5 +
      healthScore
    ) / 4
  )
);

let viralStatus = "Low Chance";

if (viralProbability >= 85) {
  viralStatus = "Very High Chance";
}
else if (viralProbability >= 70) {
  viralStatus = "High Chance";
}
else if (viralProbability >= 50) {
  viralStatus = "Medium Chance";
}

let trendingStatus = "Waiting...";

if (trendingScore >= 90) {
  trendingStatus = "Very High Chance To Trend";
} else if (trendingScore >= 75) {
  trendingStatus = "High Chance To Trend";
} else if (trendingScore >= 60) {
  trendingStatus = "Medium Chance To Trend";
} else if (trendingScore > 0) {
  trendingStatus = "Low Chance To Trend";
}

let healthStatus = "Waiting...";
if (healthScore >= 90) healthStatus = "Excellent";
else if (healthScore >= 75) healthStatus = "Strong";
else if (healthScore >= 60) healthStatus = "Average";
else if (healthScore > 0) healthStatus = "Needs Work";

  document.getElementById("viraseo-score").textContent =
    result.score + "/100";

  document.getElementById("viraseo-ctr").textContent =
    ctr + "%";

   // document.getElementById("viraseo-health-score").textContent =
  //healthScore + "/100";

// document.getElementById("viraseo-health-status").textContent =
  //healthStatus;

 // document.getElementById("viraseo-trending-score").textContent =
  //trendingScore + "/100";

  

//document.getElementById("viraseo-trending-status").textContent =
  trendingStatus;

  //document.getElementById("viraseo-upload-day").textContent =
  uploadTime.day;

//document.getElementById("viraseo-upload-hours").textContent =
  uploadTime.hours;

//document.getElementById("viraseo-upload-score").textContent =
  "Score: " + uploadTime.score + "/100";

document.getElementById("viraseo-viral-score").textContent =
  viralProbability + "%";

  

  

  const hooks = [];

const lower = title.toLowerCase();

if (/\d/.test(title)) hooks.push("🔢 Numbers");

if (
  lower.includes("how") ||
  lower.includes("why") ||
  lower.includes("secret") ||
  lower.includes("hidden")
) {
  hooks.push("🧠 Curiosity");
}

if (
  lower.includes("best") ||
  lower.includes("guide") ||
  lower.includes("tutorial") ||
  lower.includes("tips")
) {
  hooks.push("🎯 Benefit");
}

if (
  lower.includes("warning") ||
  lower.includes("mistake") ||
  lower.includes("never")
) {
  hooks.push("⚡ Urgency");
}

if (
  lower.includes("crazy") ||
  lower.includes("shocking") ||
  lower.includes("unbelievable")
) {
  hooks.push("🔥 Emotion");
}

document.getElementById("viraseo-viral").innerHTML =
  hooks.length
    ? hooks.map((h) => `<span>${h}</span>`).join("")
    : "<span>❌ No strong hooks detected</span>";

      function setMeter(id, textId, value) {
  const bar = document.getElementById(id);
  const text = document.getElementById(textId);

  if (bar) bar.style.width = value + "%";
  if (text) text.textContent = value + "%";
}

setMeter("meter-seo", "meter-seo-text", meters.seo);
setMeter("meter-curiosity", "meter-curiosity-text", meters.curiosity);
setMeter("meter-emotion", "meter-emotion-text", meters.emotion);
setMeter("meter-clickability", "meter-clickability-text", meters.clickability);

  const gradeEl = document.getElementById("viraseo-grade");

  if (gradeEl) {
    if (!title) {
      gradeEl.textContent = "-";
      gradeEl.className = "viraseo-grade";
    } else {
      let grade = "D";

      if (result.score >= 90) grade = "A+";
      else if (result.score >= 80) grade = "A";
      else if (result.score >= 70) grade = "B";
      else if (result.score >= 60) grade = "C";

      gradeEl.textContent = grade;
      gradeEl.className =
        "viraseo-grade grade-" + grade.replace("+", "plus");
    }
  }
}
  setInterval(updatePanel, 1200);
})();